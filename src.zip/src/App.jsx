import { useEffect, useState } from "react";
import { HashRouter, Route, Routes } from "react-router-dom";
import Home from "./page/home/home";
import Todo from "./page/todo/todo";
import Calculator from "./page/Calculator/Calculator";
import Layout from "./layout/Layout/Layout";

import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap-icons/font/bootstrap-icons.css";

import "./App.css";

const intTab = "home";

function App() {
  const [tab, setTab] = useState("");

  useEffect(() => {
    setTab(intTab);
  }, []);

  return (
    <div className="app-container">
      <HashRouter>
        <Routes>
          <Route element={<Layout tab={tab} setTab={setTab} />}>
            <Route path="/" element={<Home />} />
            <Route path="/todo" element={<Todo />} />
            <Route path="/calculator" element={<Calculator />} />
            <Route path="/home" element={<Home />} />
          </Route>
        </Routes>
      </HashRouter>
    </div>
  );
}

export default App;
