import './home.css';

function Home() {
    return ( 
        <div className='home-container'>
            <h1>introduce Yourself</h1>
        </div>
     );
}

export default Home;