import './calculator.css';

function Calculator() {
    return ( 
        <div>
            <h1>Calculator</h1>
        </div>
     );
}

export default Calculator;