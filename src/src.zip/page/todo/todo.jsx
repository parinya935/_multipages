import { useState, useEffect } from "react";
import { fetchTodos } from "../../data/todo";
import "./todo.css";

const initItemPerPage = 5;
const initOnlyWaiting = false;

function Todo() {
  const [todosRaw, setTodosRaw] = useState([]);

  const [onlyWaiting, setOnlyWaiting] = useState(false);
  const [itemPerPages, setItemPerPages] = useState(5);

  const [todos, setTodos] = useState([]);

  const [numPages, setNumPages] = useState(0);
  const [currentPage, setCurrentPage] = useState(0);

  const itemPerPagesRef = useRef();
  const onlyWaitingRef = useRef();

  useEffect(() => {
    setTodosRaw(fetchTodos());
  }, []);

  useEffect(() => {
    console.log(`onlyWaiting: ${onlyWaiting}`);
  }, [onlyWaiting]);

  useEffect(() => {
    // setCurrentPage( (prev) => (prev > numPages ? numPages : prev))
    setCurrentPage(1);
  }, [numPages]);

  useEffect(() => {
    console.log(`itemPerPages: ${itemPerPages}`);
    setNumPages(Math.ceil(todosRaw.length / itemPerPages));
  }, [itemPerPages, todosRaw]);

  useEffect(() => {
    if (onlyWaiting) {
      setTodos(
        todosRaw.filter((todo) => {
          !todo.completed;
        })
      );
    } else {
      setTodos(todosRaw);
    }
  }, [todosRaw, onlyWaiting, itemPerPages]);

  function deleteClick(id) {
    const todosReamain = todosRaw.filter((todo) => {
      return todo.id !== id;
    });

    setTodosRaw(todosReamain);
  }

  return (
    <div className="todo-container">
      <div className="todo-filers-container">
        {/* filter */}
        <div>
          <div className="form-check form-switch">
            <input
              className="form-check-input"
              type="checkbox"
              role="switch"
              id="flexSwitchCheckChecked"
              // checked
              onClick={(e) => {
                setOnlyWaiting(e.target.checked);
              }}
              ref={onlyWaitingRef}
            />
            <label
              className="form-check-label"
              htmlFor="flexSwitchCheckChecked"
            >
              Show only &nbsp;
              <button className="btn btn-warning">
                waiting&nbsp; <span className="bi bi-clock"></span>
              </button>
            </label>
          </div>
        </div>
        <select
          className="form-select"
          aria-label="Default select example"
          defaultValue={5}
          style={{ width: "200px" }}
          onChange={(e) => {
            setItemPerPages(e.target.value);
          }}
          ref={itemPerPagesRef}
        >
          <option value={5} selected>
            5 item per page
          </option>
          <option value={10}>10 item per page</option>
          <option value={50}>50 item per page</option>
          <option value={100}>100 item per page</option>
        </select>
      </div>

      {/* table */}
      <table className="table table-striped">
        <thead className="table-dark">
          <tr>
            <th style={{ width: "10%" }}>ID</th>
            <th>Title</th>
            <th style={{ textAlign: "right" }}>Completed</th>
          </tr>
        </thead>
        <tbody>
          {
            /* <tr>
                <td><span className="badge bg-secondary">1</span></td>
                <td style={{textAlign: "left"}}>Task 1</td>
                <td style={{textAlign: "right"}}>status <button className="btn btn-danger"><span className="bi bi-trash"></span></button></td>
            </tr> */

            todos
              .filter((todo, index) => {
                const min = (currentPage - 1) * itemPerPages;
                const max = currentPage * itemPerPages - 1;
                return index >= min && index <= max;
              })
              .map((todo) => {
                return (
                  <tr key={todo.id}>
                    <td>
                      <span
                        className="badge bg-secondary"
                        style={{ width: "3rem" }}
                      >
                        {todo.id}
                      </span>
                    </td>
                    <td style={{ textAlign: "left" }}>{todo.title}</td>
                    <td style={{ textAlign: "right" }}>
                      <span
                        className={
                          "badge " +
                          (todo.completed ? "bg-success" : "bg-warning")
                        }
                      >
                        {todo.completed ? "done" : "waiting"}
                        &nbsp;
                        <span
                          className={
                            "bi " + (todo.completed ? " bi-check" : "bi-clock")
                          }
                        ></span>
                      </span>
                      <button
                        className="btn btn-danger"
                        onClick={() => {
                          deleteClick(todo.id);
                        }}
                      >
                        <span className="bi bi-trash"></span>
                      </button>
                    </td>
                  </tr>
                );
              })
          }
        </tbody>
      </table>

      {/* page control */}
      <div>
        <button
          className="btn btn-outline-primary todo-space"
          onClick={() => setCurrentPage(1)}
          disabled={currentPage === 1}
        >
          First
        </button>
        <button
          className="btn btn-outline-primary todo-space"
          onClick={() => currentPage > 1 && setCurrentPage(currentPage - 1)}
          disabled={currentPage === 1}
        >
          Previous
        </button>
        <span className="todo-space">
          {currentPage}&nbsp;/&nbsp;{numPages}
        </span>
        <button
          className="btn btn-outline-primary todo-space"
          onClick={() => {
            currentPage < numPages && setCurrentPage(currentPage + 1);
          }}
          disabled={currentPage === numPages}
        >
          Next
        </button>
        <button
          className="btn btn-outline-primary todo-space"
          onClick={() => setCurrentPage(numPages)}
          disabled={currentPage === numPages}
        >
          Last
        </button>
      </div>
    </div>
  );
}

export default Todo;
